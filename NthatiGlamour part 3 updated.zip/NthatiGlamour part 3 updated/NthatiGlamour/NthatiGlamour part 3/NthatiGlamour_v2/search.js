

let siteContent = [
    {
        title: 'Home',
        url: 'index.html',
        keywords: ['home', 'glamour', 'beauty', 'nthati', 'welcome', 'services', 'hair', 'makeup'],
        description: 'Welcome to NthatiGlamour — premium hair products and professional makeup services in Johannesburg.'
    },
    {
        title: 'About Nthati Moloi',
        url: 'about.html',
        keywords: ['about', 'nthati', 'moloi', 'founder', 'story', 'mission', 'vision', 'certified', 'artist'],
        description: 'Meet Nthati Moloi, certified makeup artist and founder of NthatiGlamour since 2020.'
    },
    {
        title: 'Bridal Makeup',
        url: 'services.html',
        keywords: ['bridal', 'bride', 'wedding', 'trial', 'r1200', 'r1,200', 'package'],
        description: 'Full bridal makeup package including trial session, day-of application and touch-up kit. R1,200.'
    },
    {
        title: 'Everyday Glam',
        url: 'services.html',
        keywords: ['everyday', 'glam', 'daily', 'natural', 'work', 'casual', 'r350'],
        description: 'Natural polished makeup look for daily wear or work. R350 — 45 minutes.'
    },
    {
        title: 'Evening Look',
        url: 'services.html',
        keywords: ['evening', 'night', 'dramatic', 'party', 'dinner', 'r500'],
        description: 'Dramatic sophisticated makeup for special nights out. R500 — 60 minutes.'
    },
    {
        title: 'Special Events Makeup',
        url: 'services.html',
        keywords: ['events', 'special', 'photoshoot', 'formal', 'bridesmaids', 'r450'],
        description: 'Custom makeup for photoshoots, formal events and weddings. R450 — 60 minutes.'
    },
    {
        title: 'Lace Wigs',
        url: 'services.html',
        keywords: ['lace', 'wig', 'wigs', 'lace front', 'r1200', 'styles', 'textures'],
        description: 'Premium lace front wigs in various styles and textures. From R1,200.'
    },
    {
        title: 'Hair Extensions',
        url: 'services.html',
        keywords: ['extensions', 'clip', 'weft', 'human hair', 'virgin', 'r450'],
        description: '100% human hair extensions, clip-ins and weft options. From R450.'
    },
    {
        title: 'Hair Care Products',
        url: 'services.html',
        keywords: ['shampoo', 'conditioner', 'treatment', 'care', 'products', 'r120'],
        description: 'Shampoos, conditioners and treatments for healthy hair. From R120.'
    },
    {
        title: 'Styling Tools',
        url: 'services.html',
        keywords: ['flat iron', 'curling', 'wand', 'tools', 'styling', 'r350'],
        description: 'Professional flat irons, curling wands and accessories. From R350.'
    },
    {
        title: 'Book an Appointment',
        url: 'form.html',
        keywords: ['book', 'booking', 'appointment', 'reserve', 'session', 'enquiry', 'form'],
        description: 'Fill in your details and we will confirm your appointment within 24 hours.'
    },
    {
        title: 'Contact Us',
        url: 'contact.html',
        keywords: ['contact', 'phone', 'email', 'whatsapp', 'address', 'location', 'find us'],
        description: 'Call, email or WhatsApp NthatiGlamour. Visit us at 123 Beauty Street, Johannesburg.'
    },
    {
        title: 'Opening Hours',
        url: 'contact.html',
        keywords: ['hours', 'opening', 'times', 'monday', 'friday', 'saturday', 'open', 'closed'],
        description: 'Open Monday to Friday 09:00–18:00. Saturday 10:00–17:00. Closed Sundays.'
    },
    {
        title: 'Location & Map',
        url: 'contact.html',
        keywords: ['location', 'map', 'directions', 'johannesburg', 'gauteng', 'address', 'street'],
        description: '123 Beauty Street, Johannesburg, 2000, Gauteng, South Africa.'
    }
];

let params = new URLSearchParams(window.location.search);
let query = params.get('q');

let queryDisplay = document.getElementById('search-query-display');
let resultsContainer = document.getElementById('search-results');

if (!query || query.trim() === '') {
    queryDisplay.textContent = 'Please enter a search term.';
    resultsContainer.innerHTML = '';
} else {
    queryDisplay.textContent = 'Showing results for: "' + query + '"';

    let searchTerm = query.toLowerCase().trim();
    let matches = siteContent.filter(function(item) {
        return item.title.toLowerCase().includes(searchTerm) ||
               item.description.toLowerCase().includes(searchTerm) ||
               item.keywords.some(function(keyword) {
                   return keyword.includes(searchTerm);
               });
    });

    if (matches.length === 0) {
        resultsContainer.innerHTML =
            '<div style="text-align:center; padding: 2rem;">' +
            '<p>No results found for &ldquo;' + query + '&rdquo;.</p>' +
            '<p style="margin-top:1rem; color:var(--muted);">Try searching for: makeup, bridal, wigs, extensions, pricing, booking or contact.</p>' +
            '<a href="index.html" class="btn" style="margin-top:1.5rem;">Back to Home</a>' +
            '</div>';
    } else {
        let html = '<div class="results-grid">';
        matches.forEach(function(item) {
            html +=
                '<div class="result-card">' +
                '<h3>' + item.title + '</h3>' +
                '<p>' + item.description + '</p>' +
                '<br>' +
                '<a href="' + item.url + '" class="btn">View Page</a>' +
                '</div>';
        });
        html += '</div>';
        resultsContainer.innerHTML = html;
    }
}
