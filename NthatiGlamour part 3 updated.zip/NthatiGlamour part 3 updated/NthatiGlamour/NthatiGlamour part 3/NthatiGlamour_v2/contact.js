
const SERVICE_ID = 'service_6nc5mdq';
const TEMPLATE_ID = 'template_oun5nx7';
const PUBLIC_KEY = 'JKloS0KK_HdnQPF9I';

document.getElementById('contact-form').addEventListener('submit', function(event) {
    event.preventDefault();

    let errors = document.querySelectorAll('.error-message');
    errors.forEach(function(error) { error.remove(); });

    let isValid = true;

    let name = document.getElementById('contact-name').value.trim();
    if (name === '') {
        showError('contact-name', 'Please enter your name');
        isValid = false;
    }

    let email = document.getElementById('contact-email').value.trim();
    let emailFormat = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (email === '') {
        showError('contact-email', 'Please enter your email');
        isValid = false;
    } else if (!emailFormat.test(email)) {
        showError('contact-email', 'Please enter a valid email address');
        isValid = false;
    }

    let phone = document.getElementById('contact-phone').value.trim();
    if (phone !== '') {
        let phoneFormat = /^[\d\s\+\-\(\)]{7,15}$/;
        if (!phoneFormat.test(phone)) {
            showError('contact-phone', 'Please enter a valid phone number');
            isValid = false;
        }
    }

    let subject = document.getElementById('contact-subject').value.trim();
    if (subject === '') {
        showError('contact-subject', 'Please enter a subject');
        isValid = false;
    }

    let message = document.getElementById('contact-message').value.trim();
    if (message === '') {
        showError('contact-message', 'Please enter your message');
        isValid = false;
    } else if (message.length < 10) {
        showError('contact-message', 'Message must be at least 10 characters');
        isValid = false;
    }

    if (isValid) {
        emailjs.sendForm(SERVICE_ID, TEMPLATE_ID, this, PUBLIC_KEY)
            .then(function() {
                document.getElementById('form-response').innerHTML =
                    '<div class="success-message">' +
                    '<h3>Message Sent!</h3>' +
                    '<p>Thank you for reaching out. We will get back to you within 24 hours.</p>' +
                    '</div>';
                document.getElementById('contact-form').reset();
                document.getElementById('char-counter').textContent = '0 / 500 characters';
            })
            .catch(function(error) {
                document.getElementById('form-response').innerHTML =
                    '<div class="error-box">' +
                    '<p>Something went wrong. Please try again or WhatsApp us directly.</p>' +
                    '</div>';
                console.error('EmailJS error:', error);
            });
    }
});

function showError(fieldId, message) {
    let field = document.getElementById(fieldId);
    let error = document.createElement('p');
    error.className = 'error-message';
    error.textContent = message;
    field.parentElement.appendChild(error);
}

let messageField = document.getElementById('contact-message');
let charCounter = document.getElementById('char-counter');

messageField.addEventListener('input', function() {
    let count = this.value.length;
    let max = 500;
    charCounter.textContent = count + ' / ' + max + ' characters';
    charCounter.classList.remove('warning', 'danger');
    if (count >= 400 && count < 480) {
        charCounter.classList.add('warning');
    } else if (count >= 480) {
        charCounter.classList.add('danger');
    }
});

let map = L.map('leaflet-map').setView([-26.2041, 28.0473], 14);

L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
    attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
}).addTo(map);

let marker = L.marker([-26.2041, 28.0473]).addTo(map);
marker.bindPopup(
    '<b>NthatiGlamour</b><br>' +
    '123 Beauty Street<br>' +
    'Johannesburg, 2000<br>' +
    '<a href="https://maps.google.com/?q=Johannesburg" target="_blank">Get Directions</a>'
).openPopup();
