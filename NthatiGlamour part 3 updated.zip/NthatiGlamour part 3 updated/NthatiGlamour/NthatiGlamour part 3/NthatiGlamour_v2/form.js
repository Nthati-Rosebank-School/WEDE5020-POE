
const SERVICE_ID = 'service_6nc5mdq';
const TEMPLATE_ID = 'template_oun5nx7';
const PUBLIC_KEY = 'JKloS0KK_HdnQPF9I';

let dateInput = document.getElementById('date');
if (dateInput) {
    dateInput.min = new Date().toISOString().split('T')[0];
}

document.getElementById('booking-form').addEventListener('submit', function(event) {
    event.preventDefault();

    let errors = document.querySelectorAll('.error-message');
    errors.forEach(function(error) { error.remove(); });

    let isValid = true;

    let name = document.getElementById('name').value.trim();
    if (name === '') {
        showError('name', 'Please enter your name');
        isValid = false;
    } else if (name.length < 2) {
        showError('name', 'Name must be at least 2 characters');
        isValid = false;
    }

    let email = document.getElementById('email').value.trim();
    let emailFormat = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (email === '') {
        showError('email', 'Please enter your email');
        isValid = false;
    } else if (!emailFormat.test(email)) {
        showError('email', 'Please enter a valid email address');
        isValid = false;
    }

    let phone = document.getElementById('phone').value.trim();
    let phoneFormat = /^[\d\s\+\-\(\)]{7,15}$/;
    if (phone === '') {
        showError('phone', 'Please enter your phone number');
        isValid = false;
    } else if (!phoneFormat.test(phone)) {
        showError('phone', 'Please enter a valid phone number');
        isValid = false;
    }

    let serviceType = document.getElementById('service-type').value;
    if (serviceType === '') {
        showError('service-type', 'Please select a service');
        isValid = false;
    }

    let date = document.getElementById('date').value;
    if (date === '') {
        showError('date', 'Please select a preferred date');
        isValid = false;
    } else {
        let selectedDate = new Date(date);
        let today = new Date();
        today.setHours(0, 0, 0, 0);
        if (selectedDate < today) {
            showError('date', 'Please select a future date');
            isValid = false;
        }
    }

    let time = document.getElementById('time').value;
    if (time === '') {
        showError('time', 'Please select a preferred time');
        isValid = false;
    }


    if (isValid) {
        emailjs.sendForm(SERVICE_ID, TEMPLATE_ID, this, PUBLIC_KEY)
            .then(function() {
                document.getElementById('booking-response').innerHTML =
                    '<div class="success-message">' +
                    '<h3>Booking Request Received!</h3>' +
                    '<p>Thank you for booking with NthatiGlamour.</p>' +
                    '<p>We will contact you within 24 hours to confirm your appointment.</p>' +
                    '<a href="index.html" class="btn">Back to Home</a>' +
                    '</div>';
                document.getElementById('booking-form').reset();
            })
            .catch(function(error) {
                document.getElementById('booking-response').innerHTML =
                    '<div class="error-box">' +
                    '<p>Something went wrong. Please try again or WhatsApp us directly.</p>' +
                    '</div>';
                console.error('EmailJS error:', error);
            });
    }
});

function showError(fieldId, message) {
    let field = document.getElementById(fieldId);
    if (field) {
        let error = document.createElement('p');
        error.className = 'error-message';
        error.textContent = message;
        field.parentElement.appendChild(error);
    }
}

let messageField = document.getElementById('message');
let charCounter = document.getElementById('char-counter');

if (messageField && charCounter) {
    messageField.addEventListener('input', function() {
        let count = this.value.length;
        let max = 500;
        charCounter.textContent = count + ' / ' + max + ' characters';
        charCounter.classList.remove('warning', 'danger');
        if (count >= 400 && count < 480) {
            charCounter.classList.add('warning');
        } else if (count >= 480) {
            charCounter.classList.add('danger');
        }
    });
}
