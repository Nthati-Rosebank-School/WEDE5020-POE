
let triggers = document.querySelectorAll('.lightbox-trigger');
let lightbox = document.getElementById('lightbox');
let lightboxImg = document.getElementById('lightbox-img');
let lightboxCaption = document.getElementById('lightbox-caption');
let lightboxClose = document.getElementById('lightbox-close');

triggers.forEach(function(trigger) {
    trigger.addEventListener('click', function() {
        lightbox.style.display = 'flex';
        lightboxImg.src = this.getAttribute('data-src');
        lightboxCaption.textContent = this.getAttribute('data-caption');
    });
});

lightboxClose.addEventListener('click', function() {
    lightbox.style.display = 'none';
});

lightbox.addEventListener('click', function(event) {
    if (event.target === lightbox) {
        lightbox.style.display = 'none';
    }
});

document.addEventListener('keydown', function(event) {
    if (event.key === 'Escape') {
        lightbox.style.display = 'none';
    }
});

let filterBtns = document.querySelectorAll('.filter-btn');
let serviceCards = document.querySelectorAll('.service-card');

filterBtns.forEach(function(btn) {
    btn.addEventListener('click', function() {
        filterBtns.forEach(function(b) { b.classList.remove('active'); });
        this.classList.add('active');

        let filter = this.getAttribute('data-filter');

        serviceCards.forEach(function(card) {
            if (filter === 'all' || card.getAttribute('data-category') === filter) {
                card.style.display = 'block';
            } else {
                card.style.display = 'none';
            }
        });
    });
});
