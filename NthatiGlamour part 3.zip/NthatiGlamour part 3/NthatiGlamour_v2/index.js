
let testimonials = [
    {
        name: 'Lerato M.',
        text: 'Nthati did my bridal makeup and I felt absolutely stunning. Every photo looked incredible!',
        stars: 5
    },
    {
        name: 'Thandeka K.',
        text: 'I love my new lace wig — the quality is incredible and the fitting was perfect.',
        stars: 5
    },
    {
        name: 'Ayanda P.',
        text: 'My evening glam look was everything I imagined. Nthati really listens to what you want!',
        stars: 5
    },
    {
        name: 'Zintle N.',
        text: 'Got my hair extensions here and the quality is unmatched. Will definitely be back!',
        stars: 5
    }
];

let testimonialTrack = document.getElementById('testimonial-track');

testimonials.forEach(function(t) {
    let card = document.createElement('div');
    card.className = 'testimonial-card';
    card.innerHTML =
        '<p class="stars">' + '&#9733;'.repeat(t.stars) + '</p>' +
        '<p class="quote">&ldquo;' + t.text + '&rdquo;</p>' +
        '<p class="author">&mdash; ' + t.name + '</p>';
    testimonialTrack.appendChild(card);
});

let accordionBtns = document.querySelectorAll('.accordion-btn');

accordionBtns.forEach(function(btn) {
    btn.addEventListener('click', function() {
        let content = this.nextElementSibling;
        let isActive = this.classList.contains('active');

        accordionBtns.forEach(function(otherBtn) {
            otherBtn.classList.remove('active');
            otherBtn.nextElementSibling.style.display = 'none';
        });

        if (!isActive) {
            this.classList.add('active');
            content.style.display = 'block';
        }
    });
});
