
let loader = document.getElementById('loader');

window.addEventListener('load', function() {
    setTimeout(function() {
        loader.style.opacity = '0';
        setTimeout(function() {
            loader.style.display = 'none';
        }, 500);
    }, 1200);
});

let sections = document.querySelectorAll('section');

let observerOptions = {
    threshold: 0.1,
    rootMargin: '0px 0px -50px 0px'
};

let observer = new IntersectionObserver(function(entries) {
    entries.forEach(function(entry) {
        if (entry.isIntersecting) {
            entry.target.classList.add('visible');
            observer.unobserve(entry.target);
        }
    });
}, observerOptions);

sections.forEach(function(section) {
    section.classList.add('hidden');
    observer.observe(section);
});

let header = document.querySelector('header');

window.addEventListener('scroll', function() {
    if (window.scrollY > 50) {
        header.classList.add('scrolled');
    } else {
        header.classList.remove('scrolled');
    }
});

let backToTop = document.getElementById('back-to-top');

window.addEventListener('scroll', function() {
    if (window.scrollY > 300) {
        backToTop.style.display = 'block';
    } else {
        backToTop.style.display = 'none';
    }
});

backToTop.addEventListener('click', function() {
    window.scrollTo({ top: 0, behavior: 'smooth' });
});

let cookieBanner = document.getElementById('cookie-banner');

if (!localStorage.getItem('cookieConsent')) {
    cookieBanner.style.display = 'flex';
} else {
    cookieBanner.style.display = 'none';
}

document.getElementById('cookie-accept').addEventListener('click', function() {
    localStorage.setItem('cookieConsent', 'accepted');
    cookieBanner.style.display = 'none';
});

document.getElementById('cookie-decline').addEventListener('click', function() {
    localStorage.setItem('cookieConsent', 'declined');
    cookieBanner.style.display = 'none';
});
