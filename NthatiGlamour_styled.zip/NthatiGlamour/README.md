# NthatiGlamour — Premium Hair & Makeup Website

A multi-page website for **NthatiGlamour**, a South African beauty brand offering professional makeup services and premium hair products. Built as a front-end web development project.

---

## Pages

| Page | File | Description |
|------|------|-------------|
| Home | `home.html` | Hero section, service overview, and why-choose-us highlights |
| About | `about.html` | Founder bio, brand story, mission, vision, and core values |
| Products & Services | `services.html` | Pricing tables for hair products and makeup services |
| Book Now | `bookings.html` | Appointment enquiry form with service selection |
| Contact | `contact.html` | Contact form, business hours, location, and social links |

---

## Technologies Used

- **HTML5** — Semantic page structure
- **CSS3** — Custom stylesheet with responsive layout (no frameworks)
- **Google Fonts** — Cormorant Garamond (display) + Jost (body)

---

## Features

- Sticky header navigation across all pages
- Responsive grid layout (mobile, tablet, desktop)
- Booking form with fieldsets, dropdowns, date/time pickers, and radio inputs
- Pricing tables for products and services
- Hover animations and smooth CSS transitions
- Consistent branding via CSS custom properties (variables)

---

## Project Structure

```
NthatiGlamour/
│
├── home.html
├── about.html
├── services.html
├── bookings.html
├── contact.html
├── style.css
│
├── nthatigl_amour_logo.jpg
├── images.jpg
├── Nthati Moloi.jpg
├── nthatiglamour_products.jpg
├── makeup_looks_nthatiglamour.jpg
└── expert_consultation_nthatiglamour.jpg
```

---

## Design Decisions

- **Colour palette:** Cream, blush, rose, and warm gold — chosen to reflect a premium, feminine beauty brand
- **Typography:** Cormorant Garamond for headings (editorial serif) paired with Jost for body text (clean, modern)
- **Layout:** CSS Grid and Flexbox used throughout; no external CSS framework
- **CSS variables:** All colours and fonts defined as custom properties for easy global updates

---

## How to Run Locally

No build tools or servers required. Just open any `.html` file in a browser:

```bash
# Option 1 — Double-click home.html in your file explorer

# Option 2 — Use VS Code Live Server extension
# Right-click home.html → "Open with Live Server"
```

---

## Deployment

This site can be deployed via **GitHub Pages**:

1. Push the project to a public GitHub repository
2. Go to **Settings → Pages**
3. Set the source to the `main` branch and root folder `/`
4. Your site will be live at `https://yourusername.github.io/repository-name/home.html`

---

## Author

Built by **[Your Name]**  
Project for [Course/Module Name] — [Institution Name]  
&copy; 2026 NthatiGlamour. All rights reserved.
